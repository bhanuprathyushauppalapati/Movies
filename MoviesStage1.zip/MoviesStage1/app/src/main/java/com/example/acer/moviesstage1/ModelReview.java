package com.example.acer.moviesstage1;

class ModelReview {
    String a,c;

    public ModelReview(String author, String content) {
        this.a = author;
        this.c = content;
    }

    public String getA() {
        return a;
    }

    public void setA(String a) {
        this.a = a;
    }

    public String getC() {
        return c;
    }

    public void setC(String c) {
        this.c = c;
    }
}
